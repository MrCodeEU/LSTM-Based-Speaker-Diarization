import math

import numpy as np
from matplotlib import pyplot as plt
from matplotlib import cm
from scipy.ndimage import gaussian_filter
from scipy.spatial.distance import squareform, pdist, cdist, cosine
from numpy.linalg import eigh
from sklearn.cluster import KMeans, DBSCAN
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
from visualize import visualize_affinity_matrix_refinement


def construct_affinity_matrix(embeddings):
    """
    Constructs the affinity matrix from segment embeddings.

    Args:
        embeddings: A NumPy array of shape (n_segments, embedding_dim).

    Returns:
        The affinity matrix as a NumPy array.
    """

    n_segments = embeddings.shape[0]
    A = np.zeros((n_segments, n_segments))

    # Calculate cosine similarity (and hence, cosine distance)
    for i in range(n_segments):
        for j in range(n_segments):
            if i != j:
                A[i, j] = 1 - cosine(embeddings[i], embeddings[j]) / 2
            else:
                # Avoid calculating self-similarity
                A[i, j] = -1  # Placeholder, will be replaced with max

    # Replace diagonal with max values
    np.fill_diagonal(A, A.max(axis=1))
    return A


def spectral_clustering(embeddings, sigma=0.5, percentile=95, n_clusters=None, max_clusters=18, visualize=False,
                        visualizeCluster=False, random_state=0):
    # visualise the embeddings using pca
    if visualizeCluster:
        pca = PCA(n_components=2)
        embeddings = pca.fit_transform(embeddings)
        plt.scatter(embeddings[:, 0], embeddings[:, 1])
        plt.title("PCA of Embeddings")
        plt.show()
    # Step 1: Construct the affinity matrix A based on cosine similarity
    A = construct_affinity_matrix(embeddings)

    if visualize:
        visualize_affinity_matrix_refinement(A, "Original Cosine Affinity")

    # Step 2a: Gaussian Blur (optional step)
    A = gaussian_filter(A, sigma=sigma)
    if visualize:
        visualize_affinity_matrix_refinement(A, "Gaussian Blur", sigma=sigma)

    # Step 2b: Row-wise Thresholding
    for i in range(A.shape[0]):
        threshold = np.percentile(A[i], percentile)
        A[i, A[i] < threshold] *= 0.001
        # A[i, A[i] < threshold] = 0
    if visualize:
        visualize_affinity_matrix_refinement(A, "Row-wise Thresholding", percentile=percentile)

    # Step 2c: Symmetrization
    A = np.maximum(A, A.T)
    if visualize:
        visualize_affinity_matrix_refinement(A, "Symmetrized")

    # Step 2d: Diffusion
    A = np.dot(A, A.T)
    if visualize:
        visualize_affinity_matrix_refinement(A, "Diffusion")

    # Step 2e: Row-wise Max Normalization
    A = A / A.max(axis=1)[:, np.newaxis]
    if visualize:
        visualize_affinity_matrix_refinement(A, "Row-wise Max Normalized")

    # Step 3: Eigen-Decomposition
    eigenvalues, eigenvectors = eigh(A)
    eigenvalues = eigenvalues[::-1]  # Reverse to have in descending order
    eigenvectors = eigenvectors[:, ::-1]

    # Debugging: Print eigenvalues to understand the eigen-gap
    # print("Eigenvalues:", eigenvalues)

    # Determine number of clusters using the maximal eigen-gap if not given
    if n_clusters is None:
        # Calculate the eigen-gap with lambda(k) / lambda(k+1) where k is the index and lambda is the eigenvalue
        eigen_gaps = np.abs(eigenvalues[:-1] / eigenvalues[1:])
        # DEBUG PRINT EIGEN GAPS
        # print("Eigen Gaps:", eigen_gaps)

        # reduce the eigen gaps to the first max_clusters
        eigen_gaps = eigen_gaps[1:max_clusters + 1]

        n_clusters = np.argmax(eigen_gaps) + 1
        print(f"Number of clusters: {n_clusters}")

    # Step 4: Replace segment embeddings with dimensions from the largest eigen-vectors
    new_embeddings = eigenvectors[:, :n_clusters]

    # Dimensionality reduction for visualization (if needed)
    if new_embeddings.shape[1] > 2:
        pca = PCA(n_components=2)
        new_embeddings = pca.fit_transform(new_embeddings)

    # K-Means clustering
    kmeans = KMeans(n_clusters=n_clusters, init='k-means++', random_state=random_state)
    labels = kmeans.fit_predict(new_embeddings)

    if visualizeCluster and new_embeddings.shape[1] == 2:
        # visualize the clusters
        plt.scatter(new_embeddings[:, 0], new_embeddings[:, 1], c=labels, s=50, cmap='viridis')
        plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], s=200, c='red', marker='*',
                    label='Centroids')
        plt.xlabel('Feature 1')
        plt.ylabel('Feature 2')
        plt.title(f"Spectral Clustering with {n_clusters} Clusters")
        plt.legend()
        plt.show()
    elif new_embeddings.shape[1] != 2:
        print("Embeddings were not reduced to 2 dimensions for visualization. Skipping visualization.")

    return labels


def offline_kmeans(embeddings, max_clusters=10, random_state=0):
    """Performs K-means clustering with elbow method for optimal k."""

    # Step 1: Determine the optimal number of clusters (k) using the elbow method
    distortions = []
    for k in range(1, max_clusters + 1):
        kmeans = KMeans(n_clusters=k, init='k-means++', random_state=random_state)
        kmeans.fit(embeddings)
        distortions.append(kmeans.inertia_)  # Inertia is the sum of squared distances

    # Find the elbow point (hopefully)
    silhouettes = []
    for k in range(2, max_clusters):  # Try different k values (adjust the range as needed)
        kmeans = KMeans(n_clusters=k, random_state=0).fit(embeddings)
        silhouettes.append(silhouette_score(embeddings, kmeans.labels_))

    optimal_k = np.argmax(silhouettes) + 2  # Add 2 because the range started from 2

    # Step 2: K-means clustering with the optimal k
    kmeans = KMeans(n_clusters=optimal_k, init='k-means++', random_state=random_state)
    labels = kmeans.fit_predict(embeddings)

    # Step 3 (Optional): Visualize the clusters
    plt.scatter(embeddings[:, 0], embeddings[:, 1], c=labels, s=50, cmap='viridis')
    plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], s=200, c='red', marker='*',
                label='Centroids')
    plt.xlabel('Feature 1')
    plt.ylabel('Feature 2')
    plt.title(f"K-means Clustering with {optimal_k} Clusters")
    plt.legend()
    plt.show()

    return labels


def dbscan_clustering(embeddings, eps=0.5, min_samples=5, visualize=False):
    """Performs DBSCAN clustering on d-vector embeddings."""

    # Step 1: Apply DBSCAN
    dbscan = DBSCAN(eps=eps, min_samples=min_samples)
    labels = dbscan.fit_predict(embeddings)

    # Identify noise points (labeled as -1)
    core_samples_mask = np.zeros_like(dbscan.labels_, dtype=bool)
    core_samples_mask[dbscan.core_sample_indices_] = True
    noise_mask = labels == -1  # Use the noise mask to identify noise points later

    # Get the number of clusters (excluding noise)
    n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
    print(f"Number of clusters found by DBSCAN: {n_clusters}")

    # Step 2 (Optional): Evaluate using Silhouette Score
    if n_clusters > 1:
        # Calculate silhouette score only if there are more than 1 clusters
        # Exclude noise points from the silhouette score calculation
        valid_indices = ~noise_mask
        silhouette_avg = silhouette_score(embeddings[valid_indices], labels[valid_indices])
        print(f"Silhouette Score (DBSCAN): {silhouette_avg:.3f}")
    else:
        print("Silhouette Score cannot be calculated with only one cluster or all noise.")

    # Step 3 (Optional): Visualize the results
    if visualize:
        # Reduce dimensions to 2D for visualization (if necessary)
        if embeddings.shape[1] > 2:
            pca = PCA(n_components=2)
            embeddings = pca.fit_transform(embeddings)

        # Plot core points
        unique_labels = set(labels)
        colors = [cm.get_cmap("tab20")(each) for each in np.linspace(0, 1, len(unique_labels))]
        for k, col in zip(unique_labels, colors):
            if k == -1:
                # Noise points are black
                col = [0, 0, 0, 1]
            class_member_mask = (labels == k)

            # Plot core points
            xy = embeddings[class_member_mask & core_samples_mask]
            plt.plot(xy[:, 0], xy[:, 1], 'o', markerfacecolor=tuple(col),
                     markeredgecolor='k', markersize=14, label=f"Cluster {k}")

            # Plot noise points
            xy = embeddings[class_member_mask & noise_mask]  # Use noise_mask here
            plt.plot(xy[:, 0], xy[:, 1], 'x', markerfacecolor=tuple(col),
                     markeredgecolor='k', markersize=6, label=f"Noise {k}")  # Mark noise points with 'x'

        plt.title('DBSCAN Clustering Results')
        plt.legend()
        plt.show()

    return labels